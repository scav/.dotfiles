vim.o.swapfile = false
vim.o.backup = false
vim.undodir = os.getenv("HOME") .. "/.vim/undodir"
vim.o.undofile = true
