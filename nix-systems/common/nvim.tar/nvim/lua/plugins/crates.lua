return {
    'saecki/crates.nvim',
    opts = {
        event = { "BufRead Cargo.toml" },
    }
}
