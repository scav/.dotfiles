return {
    "tpope/vim-fugitive",
    keys = {
        { "<leader>gs", ":G<CR>",       desc = "Open Fugutive" },
        { "<leader>gb", ":G blame<CR>", desc = "Git blame" },
    },
}
