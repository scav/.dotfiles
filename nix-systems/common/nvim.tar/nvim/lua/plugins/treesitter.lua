return {
	'nvim-treesitter/nvim-treesitter',
	dependencies = {
	   'nvim-treesitter/nvim-treesitter-textobjects' ,
	   'nvim-treesitter/nvim-treesitter-context',
	},
	lazy = false,
	auto_install = false,
	ignore_install = {'all'},
	   highlight = {
	       enable = true,
	       disable = {},
	       textobjects = { enable = true },
	       additional_vim_regex_highlighting = false,
	   },
	   ident = { enable = true },
	   rainbow = {
	       enable = true,
	       extended_mode = true,
	       max_file_lines = nil,
	   }
}
